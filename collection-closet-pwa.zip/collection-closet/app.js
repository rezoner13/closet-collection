// ---------- Icons (minimal inline SVG, lucide-style) ----------
const ICONS = {
  plus: '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  x: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
  search: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
  star: (filled) => `<svg width="12" height="12" viewBox="0 0 24 24" fill="${filled ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  trash: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
  pencil: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>',
  book: (size=32) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`,
  dollar: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
  award: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="6"/><path d="M15.5 13.5 17 22l-5-3-5 3 1.5-8.5"/></svg>',
  camera: (size=20) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>`,
  loader: (size=20) => `<svg class="spin" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/></svg>`,
  alert: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
  gear: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>'
};

const GRADES = ['Mint', 'Near Mint', 'Very Fine', 'Fine', 'Very Good', 'Good', 'Fair', 'Poor'];
const GRADE_SHORT = { 'Mint':'MT','Near Mint':'NM','Very Fine':'VF','Fine':'FN','Very Good':'VG','Good':'GD','Fair':'FR','Poor':'PR' };
const emptyForm = () => ({ title:'', issueNumber:'', publisher:'', year:'', grade:'Near Mint', value:'', keyIssue:false, notes:'', coverImage:null });

function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
function gradeClass(grade) { return 'grade-' + (grade || 'good').toLowerCase().replace(/ /g, '-'); }
function escapeHtml(str) {
  return String(str || '').replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

// ---------- IndexedDB storage ----------
const DB_NAME = 'collection-closet-db';
const STORE = 'comics';
let dbPromise = null;

function getDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

async function dbGetAll() {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

async function dbPut(comic) {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(comic);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function dbDelete(id) {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// ---------- App state ----------
const state = {
  comics: [],
  loading: true,
  storageError: false,
  showForm: false,
  showSettings: false,
  editingId: null,
  form: emptyForm(),
  query: '',
  keyOnly: false,
  sortBy: 'added',
  confirmDeleteId: null,
  scanning: false,
  scanError: '',
  scannedPreview: null,
  apiKey: localStorage.getItem('cc-api-key') || ''
};

function setState(patch) {
  Object.assign(state, patch);
  render();
}

function render() {
  const active = document.activeElement;
  const activeId = active && active.id;
  const selStart = active && typeof active.selectionStart === 'number' ? active.selectionStart : null;
  const selEnd = active && typeof active.selectionEnd === 'number' ? active.selectionEnd : null;

  renderInner();

  if (activeId) {
    const el = document.getElementById(activeId);
    if (el && typeof el.focus === 'function') {
      el.focus();
      if (selStart !== null && el.setSelectionRange) {
        try { el.setSelectionRange(selStart, selEnd); } catch (e) {}
      }
    }
  }
}

// ---------- Data actions ----------
async function loadComics() {
  try {
    const all = await dbGetAll();
    all.sort((a, b) => (b.dateAdded || 0) - (a.dateAdded || 0));
    setState({ comics: all, loading: false });
  } catch (e) {
    setState({ loading: false, storageError: true });
  }
}

async function saveComic(comic) {
  try {
    await dbPut(comic);
    setState({ storageError: false });
    await loadComics();
  } catch (e) {
    setState({ storageError: true });
  }
}

async function deleteComicById(id) {
  try {
    await dbDelete(id);
    await loadComics();
  } catch (e) {
    setState({ storageError: true });
  }
  setState({ confirmDeleteId: null });
}

// ---------- Form handlers ----------
function openAdd() { setState({ form: emptyForm(), editingId: null, showForm: true, scannedPreview: null, scanError: '' }); }
function openEdit(comic) {
  setState({
    form: { title: comic.title, issueNumber: comic.issueNumber, publisher: comic.publisher, year: comic.year,
      grade: comic.grade, value: comic.value, keyIssue: comic.keyIssue, notes: comic.notes || '', coverImage: comic.coverImage || null },
    editingId: comic.id, showForm: true, scannedPreview: comic.coverImage || null, scanError: ''
  });
}
function closeForm() { setState({ showForm: false, editingId: null, form: emptyForm(), scannedPreview: null, scanError: '' }); }

function updateFormField(field, value) {
  state.form[field] = value; // no re-render needed for text inputs beyond what's already there
}

async function handleFormSubmit(e) {
  e.preventDefault();
  if (!state.form.title || !state.form.title.trim()) return;
  const base = { ...state.form };
  if (state.editingId) {
    const existing = state.comics.find(c => c.id === state.editingId);
    await saveComic({ ...existing, ...base, id: state.editingId });
  } else {
    await saveComic({ ...base, id: uid(), dateAdded: Date.now() });
  }
  closeForm();
}

// ---------- Cover scan (uses user's own Anthropic API key) ----------
function triggerScan() {
  if (!state.apiKey) {
    setState({ scanError: 'Add your Anthropic API key in Settings first to use cover scanning.' });
    return;
  }
  setState({ scanError: '' });
  document.getElementById('cover-file-input').click();
}

async function handleFileSelected(e) {
  const file = e.target.files && e.target.files[0];
  e.target.value = '';
  if (!file) return;

  setState({ scanning: true, scanError: '' });

  try {
    const base64Data = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result.split(',')[1]);
      reader.onerror = () => reject(new Error('read failed'));
      reader.readAsDataURL(file);
    });
    const dataUrl = `data:${file.type};base64,${base64Data}`;
    state.scannedPreview = dataUrl;
    state.form.coverImage = dataUrl;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': state.apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: file.type || 'image/jpeg', data: base64Data } },
            { type: 'text', text: `Look at this photo of a comic book cover. Identify it and respond with ONLY a raw JSON object, no markdown fences, no preamble, no explanation. Use this exact shape:
{"title": "series title without issue number", "issueNumber": "just the number, no #", "publisher": "publisher name", "year": "4-digit cover year if visible or known, else empty string", "keyIssue": true or false (true only if this is a well-known first appearance, origin, or otherwise significant key issue), "notes": "one short sentence, e.g. first appearance info, empty string if nothing notable"}
If you cannot identify a field confidently, use an empty string for it (or false for keyIssue). Do not guess condition/grade or monetary value — leave those out of the object entirely.` }
          ]
        }]
      })
    });

    if (!response.ok) {
      const errBody = await response.text();
      throw new Error(`API error ${response.status}: ${errBody.slice(0, 200)}`);
    }

    const data = await response.json();
    const textBlock = (data.content || []).map(b => b.text || '').join('');
    const cleaned = textBlock.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(cleaned);

    state.form.title = parsed.title || state.form.title;
    state.form.issueNumber = parsed.issueNumber || state.form.issueNumber;
    state.form.publisher = parsed.publisher || state.form.publisher;
    state.form.year = parsed.year || state.form.year;
    state.form.keyIssue = typeof parsed.keyIssue === 'boolean' ? parsed.keyIssue : state.form.keyIssue;
    state.form.notes = parsed.notes || state.form.notes;

    setState({ scanning: false, showForm: true });
  } catch (err) {
    console.error(err);
    setState({
      scanning: false,
      scanError: "Couldn't read that cover — check your API key in Settings, or try a straighter, better-lit shot."
    });
  }
}

async function handlePhotoOnlySelected(e) {
  const file = e.target.files && e.target.files[0];
  e.target.value = '';
  if (!file) return;

  try {
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error('read failed'));
      reader.readAsDataURL(file);
    });
    state.form.coverImage = dataUrl;
    setState({ scannedPreview: dataUrl, scanError: '' });
  } catch (err) {
    setState({ scanError: "Couldn't load that photo — try again." });
  }
}

// ---------- Settings ----------
function openSettings() { setState({ showSettings: true }); }
function closeSettings() { setState({ showSettings: false }); }
function saveApiKey(key) {
  localStorage.setItem('cc-api-key', key.trim());
  setState({ apiKey: key.trim(), showSettings: false });
}

// ---------- Derived data ----------
function getFiltered() {
  let list = state.comics.slice();
  if (state.query.trim()) {
    const q = state.query.toLowerCase();
    list = list.filter(c =>
      (c.title || '').toLowerCase().includes(q) ||
      (c.publisher || '').toLowerCase().includes(q) ||
      (c.issueNumber || '').toLowerCase().includes(q)
    );
  }
  if (state.keyOnly) list = list.filter(c => c.keyIssue);
  if (state.sortBy === 'title') list.sort((a, b) => a.title.localeCompare(b.title));
  else if (state.sortBy === 'value') list.sort((a, b) => (parseFloat(b.value) || 0) - (parseFloat(a.value) || 0));
  else if (state.sortBy === 'year') list.sort((a, b) => (parseInt(b.year) || 0) - (parseInt(a.year) || 0));
  else list.sort((a, b) => (b.dateAdded || 0) - (a.dateAdded || 0));
  return list;
}

function getStats() {
  const total = state.comics.length;
  const value = state.comics.reduce((sum, c) => sum + (parseFloat(c.value) || 0), 0);
  const keys = state.comics.filter(c => c.keyIssue).length;
  return { total, value, keys };
}

// ---------- Render ----------
function renderInner() {
  const app = document.getElementById('app');
  const stats = getStats();
  const filtered = getFiltered();

  app.innerHTML = `
    <header class="header">
      <div class="halftone" style="position:absolute;inset:0;opacity:0.1;pointer-events:none;"></div>
      <div class="header-inner">
        <div>
          <h1>COLLECTION CLOSET</h1>
          <p class="tagline">your back-issue collection</p>
        </div>
        <div style="display:flex;align-items:center;gap:0.75rem;">
          <button class="settings-link" id="btn-settings" style="color:#EDE4D2;">${ICONS.gear}</button>
        </div>
      </div>
      <div class="stats-strip">
        <div class="stat-box"><div class="num">${stats.total}</div><div class="lbl">Issues</div></div>
        <div class="stat-box"><div class="num">$${stats.value.toFixed(0)}</div><div class="lbl">Value</div></div>
        <div class="stat-box"><div class="num">${stats.keys}</div><div class="lbl">Key Issues</div></div>
      </div>
    </header>

    ${state.storageError ? `<div class="toast-error">Couldn't save changes right now — they may not persist. Try again in a moment.</div>` : ''}

    <div class="controls">
      <div class="search-wrap">
        ${ICONS.search}
        <input id="search-input" type="text" placeholder="Search title, publisher, issue #..." value="${escapeHtml(state.query)}" />
      </div>
      <div class="filter-row">
        <select id="sort-select">
          <option value="added" ${state.sortBy==='added'?'selected':''}>Recently Added</option>
          <option value="title" ${state.sortBy==='title'?'selected':''}>Title A–Z</option>
          <option value="value" ${state.sortBy==='value'?'selected':''}>Value High–Low</option>
          <option value="year" ${state.sortBy==='year'?'selected':''}>Year New–Old</option>
        </select>
        <button class="key-toggle ${state.keyOnly ? 'active' : ''}" id="key-toggle">
          ${ICONS.star(state.keyOnly)} Key Issues Only
        </button>
      </div>
    </div>

    <div class="list-wrap">
      ${state.loading ? `<div style="text-align:center;padding:4rem 0;font-size:0.875rem;opacity:0.6;">Loading your collection…</div>` :
        filtered.length === 0 ? renderEmptyState() : renderGrid(filtered)}
    </div>

    <input id="cover-file-input-live" type="file" accept="image/*" capture="environment" class="hidden" />
    <input id="photo-only-input-live" type="file" accept="image/*" capture="environment" class="hidden" />

    ${!state.showForm && state.scanning ? `<div class="toast">${ICONS.loader(14)} Reading cover…</div>` : ''}
    ${!state.showForm && state.scanError ? `<div class="toast-scan-error">${ICONS.alert} ${escapeHtml(state.scanError)}</div>` : ''}

    <div class="fab-wrap">
      <button class="fab-scan" id="btn-scan" ${state.scanning ? 'disabled' : ''} title="Scan a cover to auto-fill">
        ${state.scanning ? ICONS.loader(20) : ICONS.camera(20)}
      </button>
      <button class="fab-add" id="btn-add" aria-label="Add comic">${ICONS.plus}</button>
    </div>

    ${state.showForm ? renderFormModal() : ''}
    ${state.showSettings ? renderSettingsModal() : ''}
  `;

  attachEvents();
}

function renderEmptyState() {
  if (state.comics.length === 0) {
    return `<div class="empty-state">${ICONS.book(28)}<p class="empty-title">YOUR COLLECTION IS EMPTY</p><p class="empty-sub">Tap the + button to add your first comic.</p></div>`;
  }
  return `<div class="empty-state">${ICONS.book(28)}<p class="empty-sub">No comics match your search.</p></div>`;
}

function renderGrid(list) {
  return `<div class="grid">${list.map(renderCard).join('')}</div>`;
}

function renderCard(comic) {
  const isConfirming = state.confirmDeleteId === comic.id;
  return `
    <div class="card" data-id="${comic.id}">
      ${comic.coverImage ? `<img class="card-cover" src="${comic.coverImage}" alt="${escapeHtml(comic.title)} cover" />` : ''}
      ${comic.keyIssue ? `<div class="key-badge stamp">${ICONS.award}<span>KEY</span></div>` : ''}
      <div class="card-title-wrap">
        <h3 class="card-title">${escapeHtml(comic.title)}</h3>
        <p class="card-meta">${comic.issueNumber ? '#' + escapeHtml(comic.issueNumber) : ''}${comic.year ? ' · ' + escapeHtml(comic.year) : ''}</p>
        ${comic.publisher ? `<p class="card-pub">${escapeHtml(comic.publisher)}</p>` : ''}
      </div>
      <div class="card-bottom">
        <span class="grade-pill ${gradeClass(comic.grade)}">${GRADE_SHORT[comic.grade] || comic.grade || ''}</span>
        ${comic.value ? `<span class="card-value">${ICONS.dollar}${parseFloat(comic.value).toFixed(2)}</span>` : ''}
      </div>
      ${comic.notes ? `<p class="card-notes">${escapeHtml(comic.notes)}</p>` : ''}
      <div class="card-actions">
        <button class="btn-edit" data-action="edit" data-id="${comic.id}">${ICONS.pencil} Edit</button>
        ${isConfirming
          ? `<button class="btn-confirm-delete" data-action="confirm-delete" data-id="${comic.id}">Confirm?</button>`
          : `<button class="btn-delete" data-action="ask-delete" data-id="${comic.id}">${ICONS.trash}</button>`}
      </div>
    </div>
  `;
}

function renderFormModal() {
  const f = state.form;
  return `
    <div class="modal-overlay" id="form-overlay">
      <div class="modal">
        <div class="modal-header">
          <h2>${state.editingId ? 'EDIT COMIC' : 'ADD COMIC'}</h2>
          <button class="modal-close" id="btn-close-form">${ICONS.x}</button>
        </div>
        <form class="modal-form" id="comic-form">
          <div class="scan-box">
            ${state.scannedPreview
              ? `<img class="scan-preview" src="${state.scannedPreview}" alt="Cover photo" />`
              : `<div class="scan-placeholder">${ICONS.book(18)}</div>`}
            <div class="scan-info">
              <p>${state.scanning ? 'Reading cover…' : state.scannedPreview ? 'Cover photo attached' : 'Add a cover photo'}</p>
              <div style="display:flex;gap:0.375rem;flex-wrap:wrap;margin-top:0.375rem;">
                <button type="button" class="scan-btn" id="btn-scan-inline" ${state.scanning ? 'disabled' : ''}>
                  ${state.scanning ? ICONS.loader(12) : ICONS.camera(12)} ${state.scannedPreview ? 'Rescan & auto-fill' : 'Scan & auto-fill'}
                </button>
                <button type="button" class="scan-btn" id="btn-photo-only" ${state.scanning ? 'disabled' : ''}>
                  ${ICONS.camera(12)} ${state.scannedPreview ? 'Replace photo' : 'Just add photo'}
                </button>
              </div>
              ${state.scanError ? `<p class="scan-err">${escapeHtml(state.scanError)}</p>` : ''}
            </div>
          </div>

          <div class="field">
            <label>Title *</label>
            <input required id="f-title" type="text" value="${escapeHtml(f.title)}" placeholder="Amazing Spider-Man" />
          </div>

          <div class="field-row">
            <div class="field">
              <label>Issue #</label>
              <input id="f-issue" type="text" value="${escapeHtml(f.issueNumber)}" placeholder="300" />
            </div>
            <div class="field">
              <label>Year</label>
              <input id="f-year" type="text" inputmode="numeric" value="${escapeHtml(f.year)}" placeholder="1988" />
            </div>
          </div>

          <div class="field">
            <label>Publisher</label>
            <input id="f-publisher" type="text" value="${escapeHtml(f.publisher)}" placeholder="Marvel Comics" />
          </div>

          <div class="field-row">
            <div class="field">
              <label>Condition</label>
              <select id="f-grade">
                ${GRADES.map(g => `<option value="${g}" ${f.grade===g?'selected':''}>${g}</option>`).join('')}
              </select>
            </div>
            <div class="field">
              <label>Value ($)</label>
              <input id="f-value" type="text" inputmode="decimal" value="${escapeHtml(f.value)}" placeholder="45.00" />
            </div>
          </div>

          <label class="checkbox-row">
            <input id="f-key" type="checkbox" ${f.keyIssue ? 'checked' : ''} />
            <span>Mark as key issue</span>
          </label>

          <div class="field">
            <label>Description</label>
            <textarea id="f-notes" rows="2" placeholder="First appearance of..., signed, missing staples...">${escapeHtml(f.notes)}</textarea>
          </div>

          <button type="submit" class="submit-btn">${state.editingId ? 'SAVE CHANGES' : 'ADD TO COLLECTION'}</button>
        </form>
      </div>
    </div>
  `;
}

function renderSettingsModal() {
  return `
    <div class="modal-overlay" id="settings-overlay">
      <div class="modal">
        <div class="modal-header">
          <h2>SETTINGS</h2>
          <button class="modal-close" id="btn-close-settings">${ICONS.x}</button>
        </div>
        <div class="settings-body">
          <div class="field">
            <label>Anthropic API Key (for cover scanning)</label>
            <input id="s-api-key" type="password" value="${escapeHtml(state.apiKey)}" placeholder="sk-ant-..." />
          </div>
          <p class="settings-note">
            Cover scanning calls the Anthropic API directly from your browser using this key, which is stored only on this device (localStorage) — it's never sent anywhere else. Anyone with access to this device's browser storage could read it, so only use a key you're comfortable having on this device, and consider setting spending limits on it in the Anthropic Console. Scanning is optional — you can always add comics manually without a key.
          </p>
          <button type="button" class="submit-btn" id="btn-save-key">SAVE KEY</button>
        </div>
      </div>
    </div>
  `;
}

// ---------- Event wiring ----------
function attachEvents() {
  const $ = (id) => document.getElementById(id);

  $('search-input') && $('search-input').addEventListener('input', (e) => setState({ query: e.target.value }));
  $('sort-select') && $('sort-select').addEventListener('change', (e) => setState({ sortBy: e.target.value }));
  $('key-toggle') && $('key-toggle').addEventListener('click', () => setState({ keyOnly: !state.keyOnly }));

  $('btn-add') && $('btn-add').addEventListener('click', openAdd);
  $('btn-scan') && $('btn-scan').addEventListener('click', triggerScan);
  $('btn-scan-inline') && $('btn-scan-inline').addEventListener('click', triggerScan);
  $('btn-settings') && $('btn-settings').addEventListener('click', openSettings);

  const liveFileInput = $('cover-file-input-live');
  if (liveFileInput) liveFileInput.addEventListener('change', handleFileSelected);
  // re-point the global trigger to this live input
  window.__scanInputEl = liveFileInput;

  const photoOnlyInput = $('photo-only-input-live');
  if (photoOnlyInput) photoOnlyInput.addEventListener('change', handlePhotoOnlySelected);
  $('btn-photo-only') && $('btn-photo-only').addEventListener('click', () => photoOnlyInput && photoOnlyInput.click());

  $('form-overlay') && $('form-overlay').addEventListener('click', (e) => { if (e.target.id === 'form-overlay') closeForm(); });
  $('btn-close-form') && $('btn-close-form').addEventListener('click', closeForm);
  $('comic-form') && $('comic-form').addEventListener('submit', (e) => {
    e.preventDefault();
    state.form.title = $('f-title').value;
    state.form.issueNumber = $('f-issue').value;
    state.form.year = $('f-year').value;
    state.form.publisher = $('f-publisher').value;
    state.form.grade = $('f-grade').value;
    state.form.value = $('f-value').value;
    state.form.keyIssue = $('f-key').checked;
    state.form.notes = $('f-notes').value;
    handleFormSubmit(e);
  });

  $('settings-overlay') && $('settings-overlay').addEventListener('click', (e) => { if (e.target.id === 'settings-overlay') closeSettings(); });
  $('btn-close-settings') && $('btn-close-settings').addEventListener('click', closeSettings);
  $('btn-save-key') && $('btn-save-key').addEventListener('click', () => saveApiKey($('s-api-key').value));

  document.querySelectorAll('[data-action="edit"]').forEach(btn => {
    btn.addEventListener('click', () => {
      const comic = state.comics.find(c => c.id === btn.dataset.id);
      if (comic) openEdit(comic);
    });
  });
  document.querySelectorAll('[data-action="ask-delete"]').forEach(btn => {
    btn.addEventListener('click', () => setState({ confirmDeleteId: btn.dataset.id }));
  });
  document.querySelectorAll('[data-action="confirm-delete"]').forEach(btn => {
    btn.addEventListener('click', () => deleteComicById(btn.dataset.id));
  });
}

// override triggerScan to use the currently-rendered live input
const _origTriggerScan = triggerScan;
triggerScan = function() {
  if (!state.apiKey) {
    setState({ scanError: 'Add your Anthropic API key in Settings first to use cover scanning.' });
    return;
  }
  setState({ scanError: '' });
  if (window.__scanInputEl) window.__scanInputEl.click();
};

// ---------- Init ----------
loadComics();
render();

